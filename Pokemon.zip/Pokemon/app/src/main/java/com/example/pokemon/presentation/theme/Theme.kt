package com.example.pokemon.presentation.theme

import androidx.compose.runtime.Composable
import androidx.wear.compose.material3.MaterialTheme

@Composable
fun PokemonTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        content = content
    )
}